﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace tema_egc_lab9
{
    public partial class Form1 : Form
    {
        private GLControl glControl;
        private Button btnExtrage;
        private Label lblStatus;
        private Timer timerAnimatie;

        private string[] texteVersete = {
            "Fiindcă atât de mult a iubit Dumnezeu lumea, că a dat pe singurul Lui Fiu, pentru ca oricine crede în El să nu piară, ci să aibă viața veșnică.\n(Ioan 3:16)",
            "Dar Dumnezeu Își arată dragostea față de noi prin faptul că, pe când eram noi încă păcătoși, Hristos a murit pentru noi.\n(Romani 5:8)",
            "Dacă ne mărturisim păcatele, El este credincios și drept ca să ne ierte păcatele și să ne curețe de orice nelegiuire.\n(1 Ioan 1:9)",
            "Isus i-a zis: „Eu sunt Calea, Adevărul și Viața. Nimeni nu vine la Tatăl decât prin Mine.”\n(Ioan 14:6)",
            "Căci toți au păcătuit și sunt lipsiți de slava lui Dumnezeu.\n(Romani 3:23)",
            "Pe El, Dumnezeu L-a rânduit mai dinainte să fie, prin credința în sângele Lui, o jertfă de ispășire.\n(Romani 3:25)",
            "Isus... a zis: „Tată, a sosit ceasul! Proslăvește pe Fiul Tău, ca și Fiul Tău să Te proslăvească pe Tine.”\n(Ioan 17:1)",
            "Și viața veșnică este aceasta: să Te cunoască pe Tine, singurul Dumnezeu adevărat, și pe Isus Hristos.\n(Ioan 17:3)",
            "Toma I-a zis: „Domnul meu și Dumnezeul meu!” Isus i-a zis: „Toma, ai crezut pentru că M-ai văzut. Ferice de cei ce n-au văzut, și au crezut.”\n(Ioan 20:28-29)",
            "Oricine crede în El nu este judecat; dar cine nu crede a și fost judecat.\n(Ioan 3:18)",
            "La început era Cuvântul, și Cuvântul era cu Dumnezeu, și Cuvântul era Dumnezeu.\n(Ioan 1:1)"
        };

        private int[] texturiVerseteID;
        private int texturaHartie;
        private float rotatieScena = 0;

        private bool seExtrage = false;
        private float animatieProgres = 0f;
        private int versetAlesIndex = 0;
        private Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
            texturiVerseteID = new int[texteVersete.Length];
            SetupCustomUI();
        }

        private void SetupCustomUI()
        {
            this.Size = new Size(1024, 768);
            this.Text = "Borcanul cu Versete - Laborator 9 EGC t.a";
            this.StartPosition = FormStartPosition.CenterScreen;

            glControl = new GLControl();
            glControl.Location = new Point(10, 10);
            glControl.Size = new Size(980, 600);
            glControl.Load += GlControl_Load;
            glControl.Paint += GlControl_Paint;
            this.Controls.Add(glControl);

            btnExtrage = new Button();
            btnExtrage.Text = "Extrage un Verset";
            btnExtrage.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            btnExtrage.BackColor = Color.LightGoldenrodYellow;
            btnExtrage.Location = new Point(380, 630);
            btnExtrage.Size = new Size(240, 50);
            btnExtrage.Click += BtnExtrage_Click;
            this.Controls.Add(btnExtrage);

            lblStatus = new Label();
            lblStatus.Text = "Apasa butonul pentru un verset din Biblie.";
            lblStatus.Font = new Font("Segoe UI", 10);
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(10, 630);
            this.Controls.Add(lblStatus);

            timerAnimatie = new Timer();
            timerAnimatie.Interval = 16;
            timerAnimatie.Tick += TimerAnimatie_Tick;
        }

        private void GlControl_Load(object sender, EventArgs e)
        {
            GL.ClearColor(0.1f, 0.1f, 0.15f, 1.0f);
            GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.Texture2D);

            ConfigurareLumini();
            GenerareTexturiVersete();
            GenerareTexturaHartie();

            Matrix4 p = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, glControl.Width / (float)glControl.Height, 1.0f, 100.0f);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref p);

            Matrix4 mv = Matrix4.LookAt(new Vector3(0, 4, 11), Vector3.Zero, Vector3.UnitY);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref mv);
        }

        private void ConfigurareLumini()
        {
            GL.Enable(EnableCap.Lighting);
            GL.Enable(EnableCap.Light0);

            float[] ambient = { 0.5f, 0.5f, 0.5f, 1.0f };
            GL.Light(LightName.Light0, LightParameter.Ambient, ambient);

            float[] diffuse = { 1.0f, 1.0f, 1.0f, 1.0f };
            GL.Light(LightName.Light0, LightParameter.Diffuse, diffuse);

            float[] specular = { 1.0f, 1.0f, 1.0f, 1.0f };
            GL.Light(LightName.Light0, LightParameter.Specular, specular);

            float[] position = { 5.0f, 10.0f, 10.0f, 1.0f };
            GL.Light(LightName.Light0, LightParameter.Position, position);

            GL.Enable(EnableCap.ColorMaterial);
            GL.Material(MaterialFace.Front, MaterialParameter.Specular, new float[] { 1.0f, 1.0f, 1.0f, 1.0f });
            GL.Material(MaterialFace.Front, MaterialParameter.Shininess, 100.0f);
        }

        private void GenerareTexturiVersete()
        {
            Color bgColor = Color.FloralWhite;

            for (int i = 0; i < texteVersete.Length; i++)
            {
                Bitmap bmp = new Bitmap(512, 512);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.Clear(bgColor);
                    g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

                    Pen pen = new Pen(Color.SaddleBrown, 10);
                    g.DrawRectangle(pen, 5, 5, 502, 502);

                    StringFormat sf = new StringFormat();
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;

                    int fontSize = texteVersete[i].Length > 120 ? 20 : 26;
                    Font font = new Font("Georgia", fontSize, FontStyle.Bold | FontStyle.Italic);

                    g.DrawString(texteVersete[i], font, Brushes.Black, new RectangleF(20, 20, 472, 472), sf);
                }
                texturiVerseteID[i] = LoadTexture(bmp);
            }
        }

        private void GenerareTexturaHartie()
        {
            Bitmap bmp = new Bitmap(64, 64);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.BurlyWood);
            }
            texturaHartie = LoadTexture(bmp);
        }

        private int LoadTexture(Bitmap bmp)
        {
            int texID = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, texID);

            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
                ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, data.Width, data.Height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Bgra, PixelType.UnsignedByte, data.Scan0);

            bmp.UnlockBits(data);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            return texID;
        }

        private void GlControl_Paint(object sender, PaintEventArgs e)
        {
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            GL.PushMatrix();

            GL.Rotate(20, 1, 0, 0);
            GL.Rotate(rotatieScena, 0, 1, 0);

            GL.BindTexture(TextureTarget.Texture2D, texturaHartie);
            Random rLoc = new Random(555);

            for (int i = 0; i < 20; i++)
            {
                GL.PushMatrix();
                float x = (float)(rLoc.NextDouble() * 2.5 - 1.25);
                float z = (float)(rLoc.NextDouble() * 2.5 - 1.25);
                float rot = (float)(rLoc.NextDouble() * 360);

                GL.Translate(x, -1.8f + (i * 0.08f), z);
                GL.Rotate(rot, 0, 1, 0);
                GL.Rotate(90, 1, 0, 0);

                DrawPrism(0.25f, 1.2f, 10);
                GL.PopMatrix();
            }

            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            GL.DepthMask(false);

            GL.BindTexture(TextureTarget.Texture2D, 0);
            GL.Color4(0.8f, 0.9f, 1.0f, 0.25f);

            GL.PushMatrix();
            GL.Translate(0, -1, 0);
            DrawPrism(2.0f, 5.0f, 8);
            GL.PopMatrix();

            GL.DepthMask(true);
            GL.Disable(EnableCap.Blend);
            GL.Color4(1f, 1f, 1f, 1f);

            GL.PopMatrix();

            if (seExtrage)
            {
                DrawExtractedTicket();
            }

            glControl.SwapBuffers();
        }

        private void DrawExtractedTicket()
        {
            GL.PushMatrix();

            float startZ = 0; float endZ = 7.5f;
            float currentZ = startZ + (endZ - startZ) * animatieProgres;

            float startY = 0; float endY = 2.5f;
            float currentY = startY + (endY - startY) * animatieProgres;

            GL.Translate(0, currentY, currentZ);

            float rot = (1.0f - animatieProgres) * 1080;
            GL.Rotate(rot, 0, 1, 0);

            GL.BindTexture(TextureTarget.Texture2D, texturiVerseteID[versetAlesIndex]);

            if (animatieProgres > 0.85f)
            {
                GL.Rotate(-20, 1, 0, 0);

                float s = 2.2f;
                GL.Begin(PrimitiveType.Quads);
                GL.Normal3(0, 0, 1);

                GL.TexCoord2(0, 1); GL.Vertex3(-s, -s, 0);
                GL.TexCoord2(1, 1); GL.Vertex3(s, -s, 0);
                GL.TexCoord2(1, 0); GL.Vertex3(s, s, 0);
                GL.TexCoord2(0, 0); GL.Vertex3(-s, s, 0);
                GL.End();
            }
            else
            {
                GL.Rotate(90, 0, 0, 1);
                DrawPrism(0.3f, 3.0f, 10);
            }

            GL.PopMatrix();
        }

        private void DrawPrism(float radius, float height, int sides)
        {
            float halfH = height / 2;
            GL.Begin(PrimitiveType.QuadStrip);
            for (int i = 0; i <= sides; i++)
            {
                double angle = (Math.PI * 2.0 / sides) * i;
                float x = (float)Math.Cos(angle) * radius;
                float z = (float)Math.Sin(angle) * radius;

                GL.Normal3(x, 0, z);

                float u = (float)i / sides;
                GL.TexCoord2(u, 0); GL.Vertex3(x, halfH, z);
                GL.TexCoord2(u, 1); GL.Vertex3(x, -halfH, z);
            }
            GL.End();
        }

        private void BtnExtrage_Click(object sender, EventArgs e)
        {
            if (seExtrage) return;

            versetAlesIndex = rand.Next(0, texteVersete.Length);
            seExtrage = true;
            animatieProgres = 0f;
            lblStatus.Text = "Se extrage...";
            timerAnimatie.Start();
        }

        private void TimerAnimatie_Tick(object sender, EventArgs e)
        {
            rotatieScena += 0.2f;

            if (seExtrage)
            {
                animatieProgres += 0.015f;

                if (animatieProgres >= 1.0f)
                {
                    animatieProgres = 1.0f;
                    lblStatus.Text = "Iată versetul tău!";
                }
            }
            glControl.Invalidate();
        }
    }
}